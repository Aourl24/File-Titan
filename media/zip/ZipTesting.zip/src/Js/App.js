import React from "react";
import "./App.css";
const App = () => {
  return (
    <div>
      <h1 className="heading">Awwal don try</h1>
      <h4 className="sub-heading">
        
      </h4>
    </div>
  );
};
 
export default App;